#include <iostream>
#include <fstream>
#include <cstring>
#include "Hero.h"

namespace sict {

	Hero::Hero() {
		this->setHero("", 0, 0);
	}
	Hero::Hero(const char *pName, const int pHealth, const int pAttck) {
		this->setHero(pName, pHealth, pAttck);
	}

	void Hero::setHero(const char *pName, const int pHealth, const int pAttck) {

		if ((pName == nullptr) || (strcmp(pName, "") == 0) || (pHealth < 1) || (pAttck < 1)) { //invalid values
			strcpy(this->Name, "");
			this->Attck = 0;
			this->Health = 0;
		}
		else {
			strcpy(this->Name, pName);
			this->Attck = pAttck;
			this->Health = pHealth;
		}
	}

	void Hero::operator-= (int attack) {
		if (attack > 0) {
			this->Health -= attack;
			
		}
	}
	bool Hero::isAlive() const {
		bool healthy = false;
		if (this->Health > 0) {
			healthy = true;
		}
		return healthy;
	}
	int Hero::attackStrength() const {
		return this->Attck;
	}

	ostream& operator<<(ostream& os, const Hero& hero) {
		if (strcmp(hero.Name, "") == 0) {
			os << "No hero";
		}
		else {
			os << hero.Name;
		}
		return os;
	}

	const char* Hero::getName() {
		return this->Name;
	}

	const Hero& operator*(const Hero& first, const Hero& second) {
		Hero lFirst = first;
		Hero lSecon = second;
		//unsigned int rounds = 0;
		const Hero* champ;


		for (int i = 1; i < (max_rounds+1); i++) {
			lFirst -= lSecon.attackStrength();
			lSecon -= lFirst.attackStrength();
			if ((!(lFirst.isAlive())) || (!(lSecon.isAlive()))) {
				cout << "Ancient Battle! ";
				if (lFirst.isAlive()) {
					cout << lFirst.getName() << " vs " << lSecon.getName();
					cout << " : Winner is " << lFirst.getName();
					champ = &first;
				}
				else {
					cout << lFirst.getName() << " vs " << lSecon.getName();
					cout << " : Winner is " << lSecon.getName(); 
					champ = &second;
				}
				cout << " in " << i << " rounds." << endl;
				i = max_rounds;
			} 
		} 
		return *champ;
	}

}
