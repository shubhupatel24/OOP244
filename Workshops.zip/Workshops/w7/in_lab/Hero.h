
#define _CRT_SECURE_NO_WARNINGS
#ifndef HERO_H
#define HERO_H
#include <iostream>
#include <fstream>
#include <cstring>



using namespace std;

namespace sict {

	const int max_rounds = 100;
	const int max_name = 40;

	class Hero {

	private:
		char Name [max_name+1];
		int Health; 
		int Attck;  

		void setHero(const char*, const int, const  int);

	public:
		Hero();
		Hero(const char*, const int, const int);

		void operator-= (int attack);
		bool isAlive() const;
		int attackStrength() const;
		const char* getName();

		friend ostream& operator<<(ostream& os, const Hero& hero);
	};

	const Hero& operator*(const Hero& first, const Hero& second);
	
}

#endif
