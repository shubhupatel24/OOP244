
#include <iostream>
#include "Fraction.h"

using namespace std;
namespace sict
{
    Fraction::Fraction()
    {
	numerator = 0;
	denominator = 0;
    }
    Fraction::Fraction(int num, int den)
    {
	if (num >= 0 && den > 0)
	{
	    numerator = num;
	    denominator = den;
	    reduce();
	}
	else
	{
	    numerator = 0;
	    denominator = 0;
	}
    }
    int Fraction::max() const
    {
	int max_num;

	if (numerator >= denominator)
	     max_num = numerator;
	else
	     max_num = denominator;

	 return max_num;
    }
    int Fraction::min() const
    {
	int min_num;

	if (numerator <= denominator)
	     min_num = numerator;
	else
	     min_num = denominator;

	 return min_num;
    }
    int Fraction::gcd() const
    {
	int mn = min();
	int mx = max();
	int g_c_d = 1;
	bool found = false;

	for (int x = mn; !found && x > 0; --x)
	{
	    if (mx % x == 0 && mn % x == 0)
	    {
		found = true;
		g_c_d = x;
	    }
	}
	return g_c_d;
    }

    void Fraction::reduce()
    {
	int divisor = gcd();
	numerator /= divisor;
	denominator /= divisor;
    }
    void Fraction::display() const
    {
	bool valid = numerator >= 0 && denominator > 0;

	if (valid && denominator != 1)
	     cout << numerator << "/" << denominator;
	else if (valid && denominator == 1)
	    cout << numerator;
	else if (isEmpty())
	     cout << "no fraction stored";
    }
    bool Fraction::isEmpty() const
    {
     
	if (numerator == 0 && denominator == 0)
	  return true;
	else
	return false;
    
    }
    Fraction Fraction::operator+(const Fraction & rhs)const
    {
	Fraction fraction_sum;
	bool valid = rhs.numerator >= 0 && rhs.denominator > 0 && numerator >= 0 && denominator > 0;

	if (valid)
	{
	    fraction_sum.numerator = numerator * rhs.denominator + denominator * rhs.numerator;
	    fraction_sum.denominator = denominator * rhs.denominator;
	    fraction_sum.reduce();
	}
	else if (isEmpty() || rhs.isEmpty())
	{
	    fraction_sum = Fraction();
	}

	return fraction_sum;
    }
}
