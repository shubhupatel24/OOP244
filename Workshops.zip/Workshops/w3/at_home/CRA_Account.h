#ifndef SICT_CRA_ACCOUNT_H
#define SICT_CRA_ACCOUNT_H

//#define MAX_NAME_LENGTH 40
//#define MIN_SIN 100000000
//#define MAX_SIN 999999999

namespace sict {
 const int max_name_length = 40;
 const int min_sin = 100000000;
 const int max_sin = 999999999;
 const int max_yrs = 4; 
  class CRA_Account {
	char family_name[max_name_length + 1];
	char given_name[max_name_length + 1];
	int sin1;
	int m_year[max_yrs];
	double m_balance[max_yrs];
	int m_years;
      public:
	void set(const char* familyName, const char* givenName, int sin);
	void set(int year, double balance);
	
	bool isEmpty() const;
	bool sinvalid(int sin);
	void display() const;
    };
}
#endif
