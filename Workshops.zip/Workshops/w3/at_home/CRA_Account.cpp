#include <iostream>
#include <string.h>
#include "CRA_Account.h"

using namespace std;
namespace sict {
void CRA_Account::set(int year, double balance)
{
		m_year[m_years] = year;
		m_balance[m_years] = balance;
		m_years++;
}

void CRA_Account::set(const char *familyName, const char *givenName, int sin)
{
    
    if (sin >= min_sin && sin <= max_sin && familyName[0] != '\0' && givenName[0] != '\0' && sinvalid(sin))
   // if(isEmpty())
    {
	sin1 = sin;
	strncpy(family_name, familyName, max_name_length + 1);
	strncpy(given_name, givenName, max_name_length + 1);
       m_years = 0;
    }
    else
    {
	sin1 = 0;
	family_name[0] = '\0';
	given_name[0] = '\0';
    }
}

bool CRA_Account::isEmpty() const
{
     if (sin1 == 0){
       return  true;
     }
    else{
	return  false;
    }
		      
}

bool CRA_Account::sinvalid(int sin)
{
	int sin2 = sin; //sin2 is temporary sin number
	int digit[9];
	int sum = 0;
	int total = 0;

	for (int i = 8; i >= 0; i--){
		digit[i] = sin2 % 10;
		sin2 /= 10;
	}
	int altnumber[4] = {( digit[1] * 2 ),( digit[3] * 2 ),( digit[5] * 2 ),( digit[7] * 2 )};
	for(int i = 0; i < 4; i++){
		if(altnumber[i] >= 10){
			sum += (altnumber[i] % 10);
			sum += (altnumber[i] / 10);
		}
		else{
			sum += altnumber[i];
		}
	}
	sum += digit[0] + digit[2] + digit[4]+ digit[6] + digit[8];
	total = sum;
	if(total % 10 == 0){
		return true;
	}
	else{
		return false;
	}

}
void CRA_Account::display() const
{
   if (!isEmpty())
    {
	cout << "Family Name: " << family_name << endl;
	cout << "Given Name : " << given_name << endl;
	cout << "CRA Account: " << sin1 << endl;

	cout.setf(ios::fixed);
	cout.precision(2);
	for (int i = 0; i < m_years; i++) 
	{
	  if (m_balance[i] > 2){
	  cout << "Year (" << m_year[i] << ") balance owing: " <<
	    m_balance[i] << endl;
	  }
	  else if (m_balance[i] < -2){
	  cout << "Year (" << m_year[i] << ") refund due: " <<
		  -m_balance[i] << endl;
	  }
	  else{
	cout << "Year (" << m_year[i] << ") No balance owing or refund due!" << endl;
	}
	}  

	cout.unsetf(ios::fixed);
	cout.precision(6);
    }
    else
    {
	cout << "Account object is empty!" << endl;
    }
}
}
