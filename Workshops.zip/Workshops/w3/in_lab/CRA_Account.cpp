#include <iostream>
#include <string.h>
#include "CRA_Account.h"

using namespace std;

void sict::CRA_Account::set(const char *familyName, const char *givenName, int sin)
{
    
    if (sin >= min_sin && sin <= max_sin)
    {
	sin1 = sin;
	strncpy(family_name, familyName, max_name_length + 1);
	strncpy(given_name, givenName, max_name_length + 1);
       
    }
    else
    {
	sin1 = 0;
	family_name[0] = '\0';
	given_name[0] = '\0';
    }
}

bool sict::CRA_Account::isEmpty() const
{
     if (sin1 == 0){
	return  true;
     }
    else{
	return  false;
    }
    
}

void sict::CRA_Account::display() const
{
   if (!isEmpty())
    {
	cout << "Family Name: " << family_name << endl;
	cout << "Given Name : " << given_name << endl;
	cout << "CRA Account: " << sin1 << endl;
    }
    else
    {
	cout << "Account object is empty!" << endl;
    }
}
