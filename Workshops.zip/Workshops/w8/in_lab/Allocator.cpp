#include "SavingsAccount.h"

namespace sict {

	// define interest rate
	//
	const double interest = 0.05;

	// TODO: Allocator function
	//
	iAccount* CreateAccount(const char* type, double initBalance) {
		iAccount *p = nullptr;
		if (type[0] == 'S') p = new SavingsAccount(initBalance, interest);
		return p;
	}
	
}
