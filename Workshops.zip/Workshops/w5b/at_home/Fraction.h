// TODO: header file guard
#ifndef SICT_FRACTION_H
#define SICT_FRACTION_H
// TODO: create namespace
namespace sict
{
// TODO: define the Fraction class    
     class Fraction{
	// TODO: declare instance variables
	int numerator;
	int denominator;
	// TODO: declare private member functions
	int max() const;
	int min() const;
	int gcd() const;
	void reduce();
      public:
	// TODO: declare public member functions
	 bool isEmpty() const;
	 void display() const;
	 Fraction();
	 Fraction(int num, int den);
	// TODO: declare the + operator overload
	friend Fraction operator+(const Fraction & rhs, const Fraction & lhs);
	Fraction operator*(const Fraction & rhs)const;
	friend  bool operator==(const Fraction & rhs, const Fraction & lhs);
	friend  bool operator!=(const Fraction & rhs, const Fraction & lhs);
	 Fraction & operator+=(const Fraction & rhs);
    };
}
#endif
