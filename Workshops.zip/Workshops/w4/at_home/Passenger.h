

#ifndef SICT_PASSENGER_H
#define SICT_PASSENGER_H

namespace sict 
{
    class Passenger 
    {
	//const int max = 32;
	char name1[32];
	char destination[32];
	int year;
	int month;
	int day;
      public:
	 Passenger();
	 Passenger(const char *Name, const char *Destination);
	 Passenger(const char *Name, const char *Destination, int Year,
		   int Month, int Day);
	bool isEmpty() const;
	void display() const;
	const char *name() const;
	bool canTravelWith(const Passenger &) const;
    };
}
#endif
