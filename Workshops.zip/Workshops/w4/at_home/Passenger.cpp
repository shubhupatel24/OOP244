#include <iostream>
#include <string.h>
#include "Passenger.h"

using namespace std;
namespace sict 
{
    Passenger::Passenger() 
    {
	strncpy(name1, " ", 32);
	strncpy(destination, " ", 32);
	year = 0;
	month = 0;
	day = 0;
    } 
    Passenger::Passenger(const char *Name, const char *Destination) 
    {
	if (Name == nullptr || !strcmp(Name, "") || Destination == nullptr || !strcmp(Destination, "")) 
	{
	    strncpy(name1, " ", 32);
	    strncpy(destination, " ", 32);
	    year = 0;
	    month = 0;
	    day = 0;
	} 
	else 
	{
	    strncpy(name1, Name, 32);
	    strncpy(destination, Destination, 32);
	    year = 2017;
	    month = 7;
	    day = 1;
	}
    }
    bool Passenger::isEmpty() const 
    {

	if (strcmp(name1, " ") == 0){
	    return true;
	}    
	else{
         return false;
	}
    }
    void Passenger::display() const 
    {
	cout << name1 << " - " << destination << " on ";
	cout.fill('0');
	cout.width(4);
	cout << year << "/";
	cout.width(2);
	cout << month << "/";
	cout.width(2);
	cout << day << endl;
	cout.fill(' ');
    } 
    Passenger::Passenger(const char *Name, const char *Destination, int Year, int Month, int Day) 
    {
	bool valid = false;

	if (Name != nullptr && strcmp(Name, "") != 0
	    && Destination != nullptr && strcmp(Destination, "") != 0)
	    valid = true;
	else
	    valid = false;

	if ((Year >= 2017 && Year <= 2020) && valid)
	    valid = true;
	else
	    valid = false;

	if (Month >= 1 && Month <= 12 && valid)
	    valid = true;
	else
	    valid = false;

	if (Day >= 1 && Day <= 31 && valid)
	    valid = true;
	else
	    valid = false;

	if (valid) 
	{
	    strncpy(name1, Name, 32);
	    strncpy(destination, Destination, 32);
	    year = Year;
	    month = Month;
	    day = Day;
	} 
	else 
	{
	    strncpy(name1, " ", 32);
	    strncpy(destination, " ", 32);
	    year = 0;
	    month = 0;
	    day = 0;
	}
    }

    const char *Passenger::name() const 
    {
	return name1;
    } 
    bool Passenger::canTravelWith(const Passenger & p) const 
    {
	bool travel;

	if (!strcmp(destination, p.destination) && year == p.year
	    && month == p.month && day == p.day)
	    travel = true;
	else
	     travel = false;

	 return travel;
    }
}
