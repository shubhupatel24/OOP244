
// TODO: add file header comments here
#include <iostream>
#include <string.h>
// TODO: add your headers here

#include "Passenger.h"
// TODO: continue your namespace here
using namespace std;
namespace sict
{
// TODO: implement the default constructor here
    Passenger::Passenger()
    {
	strcpy(name, " ");
	strcpy(destination, " ");
    }
// TODO: implement the constructor with 2 parameters here
    Passenger::Passenger(const char *Name, const char *Destination)
    {
	if (Name == nullptr || !strcmp(Name, "") || Destination == nullptr
	    || !strcmp(Destination, ""))
	{
	    strcpy(name, " ");
	    strcpy(destination, " ");
	}
	else
	{
	    strcpy(name, Name);
	    strcpy(destination, Destination);
	    //strcpy("");
	}
    }
 // TODO: implement isEmpty query here
    bool Passenger::isEmpty() const
    {


	if (strcmp(name, " ") == 0){
	  return true;
	}
	else{
	  return false;
	}
	 //return false;
    }
// TODO: implement display query here
    void Passenger::display() const
    {
	if (!isEmpty()){
    	    cout <<name <<" - " << destination << endl;
	}
	else{

	cout << "No passenger!" << endl;
	}
    }
}
