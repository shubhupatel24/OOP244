#ifndef STCT_TOOLS_H
#define STCT_TOOLS_H
// Your header file content goes here
namespace sict {
	
	int getInt(int min, int max);
	// Displays the user interface menu
	int menu();
}
#endif
