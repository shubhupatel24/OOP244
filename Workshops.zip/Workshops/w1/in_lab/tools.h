#include <iostream>
// Maximum number of samples in an graph
#define MAX_NO_OF_SAMPLES 20
// Performs a fool-proof integer entry
int getInt(int min, int max);
// Displays the user interface menu
int menu();
