#ifndef PRODUCT_H
#define PRODUCT_H
#define _CRT_SECURE_NO_WARNINGS

#include <iostream>
#include <limits>
#include "ErrorState.h"


using namespace std;

namespace AMA {


	const int max_sku_length = 7;
	const int max_unit_length = 10;

	const int max_name_length = 75;

	const double TAX_RATE = 0.13;
	const char SEPARATOR(',');


	class Product {
	private:

		char Type;
		char SKU[max_sku_length + 1];
		char Unit[max_unit_length + 1];

		char * Name;
		int Quant;  

		int Need;  
		double Price; 
		bool IsTaxable;

		ErrorState _Error;

	
		void setInitialValues(const char *sku, const char *name, const char *unit,

				int quant = 0, bool isTax = true, double price = 0, int need = 0);

	public:
	
		Product();
		Product(const char *sku, const char *name, const char *unit,
	
				int quant = 0, bool isTax = true, double price = 0, int need = 0);
		
		Product(const Product &p); // constructor
		
		Product& operator= (const Product &p); 


		~Product(); //destructor

		const char* sku() const;
		const char* unit() const;
		bool taxed() const;
		
		double price() const;
		
		double total_cost() const; //returns with taxes
		
		void quantity(int);
		
		int quantity() const;
		bool isEmpty() const;
		
		int qtyNeeded() const;


		bool operator>(const char*) const;
		
		bool operator>(const Product&) const;
		int operator+=(int);
		
		bool operator==(const char*) const; //return true 

		std::fstream& store(std::fstream& file, bool newLine = true) const;
		
		std::fstream& load(std::fstream& file);
		
		std::ostream& write(std::ostream& os, bool linear) const;
		std::istream& read(std::istream& is);

	protected:
		void name(const char*);
		
		const char* name() const;
		
		double cost() const; 
		void message(const char*); 
		bool isClear() const; 
	};


	std::ostream& operator<<(std::ostream&, const Product&);
	
	std::istream& operator>>(std::istream&, Product&);
	double operator+=(double&, const Product&);

}



#endif
