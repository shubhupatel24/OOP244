

#include "Product.h"


namespace AMA {

	Product::Product() {
		setInitialValues("", "", "");
	}

	Product::Product(const Product &p) {
		setInitialValues(p.SKU, p.Name, p.Unit, p.Quant, p.IsTaxable, p.Price, p.Need);
	}

	Product& Product::operator= (const Product &p) {

		setInitialValues(p.SKU, p.Name, p.Unit, p.Quant, p.IsTaxable, p.Price, p.Need);

		return *this;

	}


	Product::Product(const char *sku, const char *name, const char *unit,int quant, bool isTax, double price, int need)
	
	{
		setInitialValues(sku, name, unit, quant, isTax, price, need);
	}
	void Product::setInitialValues(const char *sku, const char *name, const char *unit, int quant, bool isTax, double price, int need)

	{

		Name = nullptr;
		this->name(name);
		strcpy(SKU, sku);
		strcpy(Unit, unit);
		Quant = quant;
		IsTaxable = isTax;
		Price = price;
		Need = need;

	}

	void Product::name(const char* name) {

		if (!(this->Name == nullptr)) {
			delete[] Name;
		}


		if (name == nullptr) {
			Name = new char[1];
			strcpy(Name, "");
		}

		else {
			Name = new char[strlen(name) + 1];
			strcpy(Name, name);
		}

	}

	std::fstream& Product::store(std::fstream& file, bool newLine) const {
		file << SKU << SEPARATOR;

		file << Unit << SEPARATOR;
		file << Quant << SEPARATOR;
		file << IsTaxable << SEPARATOR;
		file << Price << SEPARATOR;

		file << Need << SEPARATOR;
		file << Name << SEPARATOR;  
		if (newLine == true)

		{
			file << '\n';
		}
		return file;
	}

	std::fstream& Product::load(std::fstream& file) {


		Product lProd; 

		file.getline(lProd.SKU, max_sku_length, ',');
		file.getline(lProd.Unit, max_unit_length, ',');
		file.ignore(1);
		file >> lProd.Quant;
		file.ignore(1);
		file >> lProd.IsTaxable;
		file.ignore(1);
		file >> lProd.Price;
		file.ignore(1);
		file >> lProd.Need;
		file.getline(lProd.Name, max_name_length, ',');

		*this = lProd;  


		return file;
	}
	std::ostream& Product::write(std::ostream& os, bool linear) const {

		if (linear) {
			os.unsetf(ios::right);
			os.width(max_sku_length);
			os.setf(ios::left);
			os << SKU;
			os << "|";
		
			os.width(20);
		
			os.setf(ios::left);
			os << Name;
		
			os << "|";
		
			os.unsetf(ios::left);
			os.width(7);
		
			os.setf(ios::right);
		
			os << std::fixed;
		
			os.precision(2);
		
			os << cost();
		
			os << "|";
			os.width(4);
		
		
			os << Quant;
			os << "|";
		
			os.unsetf(ios::right);
		
			os.width(10);
		
			os.setf(ios::left);
		
			os << Unit;
		
			os << "|";
			os.unsetf(ios::left);
		
			os.width(4);
			os.setf(ios::right);
			os << Need;
			os << "|";

		}
		else {
			os << "Sku: " << SKU << endl;
			os << "Name: " << Name << endl;
			os << "Price: " << Price << endl;
			if (IsTaxable) {
				os << "Price after tax: " << cost() << endl;
			}
			else {
				os << "N/A" << endl;
			}
			os << "Quantity on hand: " << Quant << endl;
			os << "Quantity needed: " << Need << endl;
		}

		return os;
	}


	
	std::istream& Product::read(std::istream& is) {


		
		Product lProd;
		
		char sku[max_sku_length + 1];
		
		char unit[max_unit_length + 1];
		
		char* name;
		
		name = new char[20];
		double price;
		
		
		char taxed;
		
		bool isTax;
		
		int quantity;
		
		int qtyNeeded;
		
		ErrorState error;



		while (!is.fail()) {  


			
			cout << " Sku: ";
			
			cin.getline(sku, max_sku_length);



			cout << " Name (no spaces): ";
			
			cin.getline(name, 20);


			
			
			cout << " Unit: ";
			
			cin.getline(unit, max_unit_length);


			cout << " Taxed? (y/n): ";
			
			
			is >> taxed;
			if (taxed == 'Y' || taxed == 'y')
			{
				isTax = true;
				is.clear();
			}
			else {
				if (taxed == 'N' || taxed == 'n') {
					isTax = false;
					is.clear();
				}
				else {
					error.message("Only (Y)es or (N)o are acceptable");
					is.setstate(ios::failbit); 
					break;
				}
			}


			
			cout << " Price: ";
			if (is >> price) {   
			
				is.clear();
			
			}
			else
			{
				error.message("Invalid Price Entry");
				break;
			}

			cout << " Quantity on hand: ";
			if (is >> quantity) {
				is.clear();
			}
			
			else
			{
				error.message("Invalid Quantity Entry");
				break;
			}

			cout << " Quantity needed: ";
			if (is >> qtyNeeded) {
				is.clear();
			}
			else
			{
				error.message("Invalid Quantity Needed Entry");
				break;
			}


		is.clear();

		cin.ignore(numeric_limits<streamsize>::max(), '\n');
		break;

		}  


		if (error.isClear()) {
			strcpy(lProd.SKU, sku);
		
			lProd.name(name);
			strcpy(lProd.Unit, unit);
		
			lProd.IsTaxable = isTax;
			lProd.Price = price;
		
			lProd.Quant = quantity;
			lProd.Need = qtyNeeded;
			lProd._Error.message(error.message());


			
			*this = lProd; //constructor
		}


		return is;
	}



	bool Product::operator==(const char*s) const {
	
		bool result = false;
		if (strcmp(SKU, s) == 0) {
	
			result = true;
		}
		return result;
	}
	bool Product::operator>(const char*s) const {
	
		return strcmp(SKU, s) > 0;

	
	}
	bool Product::operator>(const Product&p) const {
		return strcmp(Name, p.name()) > 0;
	}
	
	int Product::operator+=(int q) {
		this->Quant += q;
	
		return this->Quant;
	
	}

	
	const char* Product::sku() const { return SKU; }
	
	const char* Product::name() const { return Name; }
	
	const char* Product::unit() const { return Unit; }
	
	
	bool Product::taxed() const { return IsTaxable; }
	
	double Product::price() const { return Price; }
	
	double Product::total_cost() const { return (Quant *(this->cost())); }
	
	void Product::quantity(int q) { Quant = q; }
	
	int Product::quantity() const { return Quant; }
	
	int Product::qtyNeeded() const { return Need; }
	
	void Product::message(const char*s) { _Error.message(s); }
	
	bool Product::isClear() const { return _Error.isClear(); }


	double Product::cost() const { 
		double cost;
		if (this->IsTaxable) {
			cost = (Price + (Price * TAX_RATE));
	
		}
	
		else {
	
			cost = Price;
	
		}
	
		return cost;
	
	}



	bool Product::isEmpty() const {
		bool empty = false;
		if (strcmp(SKU, "") == 0) {
			empty = true;
		}
		return empty;
	}
	
	Product::~Product() {
		if (Name != nullptr) {
	
			delete[] Name;
	
			Name = nullptr;
	
		}
	
	}




	
	std::ostream& operator<<(std::ostream& os, const Product&p) {
	
		return os;
	
	}
	
	std::istream& operator>>(std::istream& is, Product& p) {


		
		return is;
	}

	
	double operator+=(double& d, const Product& p) {
	
		return (p.total_cost() + d);
	
	}
}



