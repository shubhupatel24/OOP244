#include <iostream>
#include <cstring>
//#include <string>
#include "ErrorState.h"

using namespace std;

namespace AMA {
	ErrorState::ErrorState(const char * errorState)
	{
		if (errorState == nullptr)
		{
			ptrState = nullptr;
		}
		else
		{
			ptrState = new char[strlen(errorState) + 1];
				strcpy(ptrState, errorState);
		}
	}
	ErrorState::~ErrorState()
	{
		delete[] ptrState;
		ptrState = nullptr;
	}
	void ErrorState::clear()
	{
		delete this->ptrState;
		ptrState = nullptr;
	}
	bool ErrorState::isClear() const
	{
		if (ptrState == nullptr)
			return true;
		else
			return false;
	}
	void ErrorState::message(const char * str)
	{
		delete[] ptrState;

		ptrState = new char[strlen(str) + 1];

		strcpy(ptrState, str);
	}
	const char* ErrorState::message()const {

		return ptrState;
	}
    std::ostream & operator<<(std::ostream& os, const ErrorState & em)
	{
		if (!em.isClear()) {
			os << em.message();
		}
		return os;
	}
}
